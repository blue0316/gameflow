import{a as t}from"../chunks/entry.CfMH__UO.js";export{t as start};
