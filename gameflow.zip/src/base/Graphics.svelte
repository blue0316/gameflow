<style>
  .custom {
    background-color:  bgColor ;
    color:  textColor ;
  }
</style>

<div class="custom">
  This div has custom background and text color.
</div>

<script>
  let bgColor = 'blue';
  let textColor = 'white';
</script>
