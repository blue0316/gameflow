export let ref = function(){
    let args = Array.from(arguments);
    args.forEach((element) => {
        
    });
}